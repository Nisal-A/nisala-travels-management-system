<?php
    $preheader = 'Action required: Document rejected for your booking';
?>

<?php $__env->startSection('content'); ?>
    <h1>Document Needs Update</h1>
    <p>Hi <?php echo e($customerName); ?>,</p>
    <p>We've reviewed the <strong><?php echo e($document->documentType->name ?? 'document'); ?></strong> you uploaded for <?php echo e($travelerName ?? 'your trip'); ?>, but unfortunately we cannot accept it in its current form.</p>
    
    <div class="callout">
        <strong>Reason for rejection:</strong><br>
        <?php echo e($document->verification_notes ?? 'The document is unclear or invalid. Please provide a clearer copy.'); ?>

    </div>

    <h2>How to re-upload</h2>
    <ol style="margin-bottom: 24px; padding-left: 20px;">
        <li style="margin-bottom: 10px;">Click the button below to go to your portal.</li>
        <li style="margin-bottom: 10px;">Locate the rejected document in the Documents section.</li>
        <li style="margin-bottom: 10px;">Upload a new file that addresses the reason mentioned above.</li>
    </ol>

    <div class="button-wrap">
        <a href="<?php echo e(url('/portal/documents')); ?>" class="button">Go to Documents</a>
    </div>

    <p>Please resolve this as soon as possible to avoid any delays with your booking processing. If you need help, feel free to reply to this email.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Nisala Travels system\nisala-travels-management-system\resources\views/emails/document/rejected.blade.php ENDPATH**/ ?>