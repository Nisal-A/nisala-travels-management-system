<?php
    $preheader = 'Your document has been verified successfully!';
?>

<?php $__env->startSection('content'); ?>
    <h1>Document Verified</h1>
    <p>Hi <?php echo e($customerName); ?>,</p>
    <p>Good news! Your <strong><?php echo e($document->documentType->name ?? 'document'); ?></strong> for <?php echo e($travelerName ?? 'your trip'); ?> has been reviewed and verified by our team.</p>
    
    <p>You're one step closer to your journey! You can check the status of all your documents anytime in your customer portal.</p>

    <div class="button-wrap">
        <a href="<?php echo e(url('/portal/documents')); ?>" class="button">View my documents</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Nisala Travels system\nisala-travels-management-system\resources\views/emails/document/verified.blade.php ENDPATH**/ ?>