<?php
    $preheader = 'Your booking ' . $booking->booking_reference . ' is confirmed!';
?>

<?php $__env->startSection('content'); ?>
    <h1>Booking Confirmed</h1>
    <p>Hi <?php echo e($customerName); ?>,</p>
    <p>Great news! Your booking <strong><?php echo e($booking->booking_reference); ?></strong> has been confirmed.</p>
    
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 24px; border-top: 1px solid #e2e8f0;">
        <tr>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;"><strong>Destination:</strong></td>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; text-align: right;"><?php echo e($booking->tourPackage->destination->name ?? 'TBA'); ?></td>
        </tr>
        <tr>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;"><strong>Dates:</strong></td>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; text-align: right;"><?php echo e(\Carbon\Carbon::parse($booking->start_date)->format('M d, Y')); ?> - <?php echo e(\Carbon\Carbon::parse($booking->end_date)->format('M d, Y')); ?></td>
        </tr>
        <tr>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;"><strong>Travelers:</strong></td>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; text-align: right;"><?php echo e($booking->travelers_count ?? 1); ?></td>
        </tr>
        <tr>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;"><strong>Total Amount:</strong></td>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; text-align: right;"><?php echo e(number_format($booking->total_price, 2)); ?> <?php echo e($booking->currency ?? 'LKR'); ?></td>
        </tr>
        <tr>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;"><strong>Amount Paid:</strong></td>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; text-align: right;"><?php echo e(number_format($booking->paid_amount ?? 0, 2)); ?> <?php echo e($booking->currency ?? 'LKR'); ?></td>
        </tr>
        <tr>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;"><strong>Balance Due:</strong></td>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; text-align: right;"><strong><?php echo e(number_format(($booking->total_price - ($booking->paid_amount ?? 0)), 2)); ?> <?php echo e($booking->currency ?? 'LKR'); ?></strong></td>
        </tr>
    </table>

    <div class="button-wrap">
        <a href="<?php echo e(url('/portal/bookings/' . $booking->id)); ?>" class="button">View my booking</a>
    </div>

    <h2>What happens next?</h2>
    <p>Please log in to your portal to upload any required travel documents (such as passport copies) and review your payment schedule.</p>
    
    <p>If you have any questions, simply reply to this email.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Nisala Travels system\nisala-travels-management-system\resources\views/emails/booking/confirmed.blade.php ENDPATH**/ ?>