<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Nisala Travels system\nisala-travels-management-system\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>