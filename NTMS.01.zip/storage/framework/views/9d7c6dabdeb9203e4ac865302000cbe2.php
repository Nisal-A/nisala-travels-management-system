<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt - <?php echo e($receipt_number); ?></title>
    <style>
        body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 14px; color: #333; line-height: 1.6; margin: 40px; }
        .header { border-bottom: 2px solid #0056b3; padding-bottom: 20px; margin-bottom: 30px; }
        .company-name { font-size: 24px; font-weight: bold; color: #0056b3; margin-bottom: 5px; }
        .title { font-size: 20px; font-weight: bold; margin-bottom: 20px; text-transform: uppercase; letter-spacing: 1px; }
        .info-table { width: 100%; margin-bottom: 30px; }
        .info-table td { vertical-align: top; width: 50%; }
        .details-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        .details-table th, .details-table td { padding: 12px; text-align: left; border-bottom: 1px solid #e0e0e0; }
        .details-table th { background-color: #f8f9fa; font-weight: bold; }
        .total-row { font-weight: bold; font-size: 16px; }
        .total-row td { border-top: 2px solid #333; }
        .footer { text-align: center; font-size: 12px; color: #777; margin-top: 50px; border-top: 1px solid #e0e0e0; padding-top: 20px; }
    </style>
</head>
<body>
    <div class="header">
        <div class="company-name"><?php echo e($company['name']); ?></div>
        <div><?php echo e($company['address']); ?></div>
        <div>Phone: <?php echo e($company['phone']); ?> | Email: <?php echo e($company['email']); ?></div>
    </div>

    <div class="title">Payment Receipt</div>

    <table class="info-table">
        <tr>
            <td>
                <strong>Billed To:</strong><br>
                <?php echo e($customer->full_name); ?><br>
                <?php echo e($customer->email); ?><br>
                <?php echo e($customer->phone); ?>

            </td>
            <td>
                <strong>Receipt No:</strong> <?php echo e($receipt_number); ?><br>
                <strong>Date:</strong> <?php echo e($payment->payment_date->format('F d, Y')); ?><br>
                <strong>Booking Ref:</strong> <?php echo e($payment->booking->booking_reference ?? 'BKG-'.$payment->booking->id); ?><br>
                <strong>Tour:</strong> <?php echo e($payment->booking->tourPackage->name ?? 'Custom Tour'); ?>

            </td>
        </tr>
    </table>

    <table class="details-table">
        <thead>
            <tr>
                <th>Description</th>
                <th>Payment Method</th>
                <th>Status</th>
                <th style="text-align: right">Amount (LKR)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Payment for Booking <?php echo e($payment->booking->booking_reference ?? 'BKG-'.$payment->booking->id); ?></td>
                <td><?php echo e(ucfirst(str_replace('_', ' ', $payment->payment_method instanceof \BackedEnum ? $payment->payment_method->value : $payment->payment_method))); ?></td>
                <td><?php echo e(ucfirst($payment->status instanceof \BackedEnum ? $payment->status->value : $payment->status)); ?></td>
                <td style="text-align: right"><?php echo e(number_format($payment->amount, 2)); ?></td>
            </tr>
            <tr class="total-row">
                <td colspan="3" style="text-align: right">Total Paid</td>
                <td style="text-align: right">Rs. <?php echo e(number_format($payment->amount, 2)); ?></td>
            </tr>
        </tbody>
    </table>

    <div class="footer">
        Thank you for choosing <?php echo e($company['name']); ?>. If you have any questions, please contact us.
    </div>
</body>
</html>
<?php /**PATH D:\Nisala Travels system\nisala-travels-management-system\resources\views/portal/receipt.blade.php ENDPATH**/ ?>