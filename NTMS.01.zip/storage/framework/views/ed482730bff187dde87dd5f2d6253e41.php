<?php echo e($slot); ?>

<?php /**PATH D:\Nisala Travels system\nisala-travels-management-system\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>