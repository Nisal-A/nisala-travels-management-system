<?php
    $preheader = 'Receipt for your recent payment of ' . number_format($payment->amount, 2) . ' ' . $payment->currency;
?>

<?php $__env->startSection('content'); ?>
    <h1>Payment Receipt</h1>
    <p>Hi <?php echo e($customerName); ?>,</p>
    <p>Thank you for your payment. We have successfully received it and applied it to your booking <strong><?php echo e($payment->booking->booking_reference ?? ''); ?></strong>.</p>
    
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 24px; border-top: 1px solid #e2e8f0;">
        <tr>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;"><strong>Amount Paid:</strong></td>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; text-align: right;"><?php echo e(number_format($payment->amount, 2)); ?> <?php echo e($payment->currency); ?></td>
        </tr>
        <tr>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;"><strong>Date:</strong></td>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; text-align: right;"><?php echo e(\Carbon\Carbon::parse($payment->payment_date)->format('M d, Y')); ?></td>
        </tr>
        <tr>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;"><strong>Payment Method:</strong></td>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; text-align: right;"><?php echo e(ucfirst($payment->payment_method)); ?></td>
        </tr>
        <tr>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;"><strong>Receipt Number:</strong></td>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; text-align: right;"><?php echo e($payment->reference_number ?? $payment->id); ?></td>
        </tr>
        <?php if($payment->booking): ?>
        <tr>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;"><strong>Remaining Balance:</strong></td>
            <td style="padding: 12px 0; border-bottom: 1px solid #e2e8f0; text-align: right;"><strong><?php echo e(number_format(($payment->booking->total_price - $payment->booking->paid_amount), 2)); ?> <?php echo e($payment->booking->currency); ?></strong></td>
        </tr>
        <?php endif; ?>
    </table>

    <div class="button-wrap">
        <a href="<?php echo e(url('/portal/payments/' . $payment->id)); ?>" class="button">Download receipt</a>
    </div>

    <p>You can always view your payment history and download receipts from your customer portal.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Nisala Travels system\nisala-travels-management-system\resources\views/emails/payment/receipt.blade.php ENDPATH**/ ?>